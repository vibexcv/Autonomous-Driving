function classifier = trainCarClassifierForViewpoint(carTrainData, carLabels, defaultLabel, trainingFeatures, numUniqueLabels)
    posLabel = int2str(defaultLabel);
    totalDataSize = length(carTrainData);
    labels = cell(totalDataSize,1);
    
    switch defaultLabel
        case 1
            viewpoint = '-120';
        case 2
            viewpoint = '-150';
        case 3
            viewpoint = '180'; % backside view
        case 4
            viewpoint = '150';
        case 5
            viewpoint = '120';
        case 6
            viewpoint = '90'; % rightside view
        case 7
            viewpoint = '60';
        case 8
            viewpoint = '30';
        case 9
            viewpoint = '0'; % frontside view
        case 10
            viewpoint = '-30';
        case 11
            viewpoint = '-60';
        case 12
            viewpoint = '-90'; % leftside view
    end
    
    % Create new label vector for positive(this viewpoint) & negative(other viewpoints)
    % All labels in order: {'-150', '-120', '-90', '-60', '-30', '0', '30', '60', '90', '120', '150', '180'}
    for j = 1:totalDataSize
        if strcmp(carLabels{j}, posLabel) % for pos
            labels{j} = viewpoint;
        else % for neg
            labels{j} = strcat('not(', viewpoint, ')');
        end
    end
    
    classifier = fitcsvm(trainingFeatures, labels);
end