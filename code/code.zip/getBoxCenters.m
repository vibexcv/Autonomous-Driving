function [xcenters, ycenters] = getBoxCenters(ds)
    x1 = ds(:,1);
    x2 = ds(:,3);
    y1 = ds(:,2);
    y2 = ds(:,4);
    xcenters = round(x1 + (x2 - x1)./2);
    ycenters = round(y1 + (y2 - y1)./2);
end