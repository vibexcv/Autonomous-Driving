function result = simpleSegmentation(depthImg, ds, thresh, tempImg)
    [r,c] = size(depthImg);
    numBoxes = size(ds, 1);
    result = cell(numBoxes, 1);
    [xcenters, ycenters] = getBoxCenters(ds);
    x1 = round(ds(:,1));
    x2 = round(ds(:,3));
    y1 = round(ds(:,2));
    y2 = round(ds(:,4));
    for i = 1:numBoxes
        cloud = [];
        centerDepth = depthImg(ycenters(i), xcenters(i));
        for x = x1(i):x2(i)
            for y = y1(i):y2(i)
                if 1 <= x && x <= c && 1 <= y && y <= r
                    currDepth = depthImg(y,x);
                    if centerDepth - thresh <= currDepth && ...
                            currDepth <= centerDepth + thresh
                        cloud = [cloud; x y currDepth];
                        tempImg(y,x) = i;
                    end
                end
            end
        end
        result{i} = cloud;
    end
    figure,
    imshow(tempImg);
end