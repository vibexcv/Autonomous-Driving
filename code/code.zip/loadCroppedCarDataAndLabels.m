function [trainData, labels] = loadCroppedCarDataAndLabels(type)
    trainingDir = fullfile('../data-car', type,'cropped-cars');
    trainingSet = imageDatastore(trainingDir);
    trainingfiles = trainingSet.Files;
    numTrainingFiles = length(trainingfiles);
    
    trainData = {};
    labels = {};

    for i = 1:numTrainingFiles
        croppedCarImg = readimage(trainingSet, i);
        trainData = [trainData; croppedCarImg];
        fileName = trainingfiles(i);
        [filepath, imgName, ext] = fileparts(char(fileName));
            
        if strcmp(type, 'train')
            parsed = strsplit(imgName, '_');
            label = char(parsed(2));
            labels = [labels; label];
        else
            labels = [labels; imgName];
        end
    end
end
