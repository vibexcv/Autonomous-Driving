function computeAndSaveDepthForCar(imset)
    destDir = fullfile('../data-car/', imset, '/results/');
    dir = fullfile(destDir, '/*_left_disparity.png');
    imgStorage = imageDatastore(dir);
    files = imgStorage.Files;
    numFiles = length(files);
    % For each image, find depth of each pixel using similar triangles.
    for i = 1:numFiles
        fileName = files(i);
        [filepath,imgName,ext] = fileparts(char(fileName));
        imgName = strsplit(imgName, '_');
        imgName = char(imgName(1));
        data = getDataCar(imgName, imset, 'calib');
        % Find f and T.
        f = data.f*10;
        T = data.baseline*1000;
        img = readimage(imgStorage,i);
        depthImage = f*T./img;
        fileName = fullfile(destDir, [imgName, '_depth_left.txt']);
        dlmwrite(fileName, depthImage);
    end
end