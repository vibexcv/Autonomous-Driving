function croppedCars = cropCarUsingDs(im, carDS)
    numCrops = size(carDS, 1);
    croppedCars = cell(numCrops, 1);
    
    if ~isempty(carDS)
        l = carDS(:,1);
        t = carDS(:,2);
        r = carDS(:,3) - l;
        b = carDS(:,4) - t;
        for j = 1:numCrops
            croppedCars{j} = imcrop(im, [l(j) t(j) r(j) b(j)]);
        end
    end
end