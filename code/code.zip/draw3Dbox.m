function draw3Dbox(im, xs, ys)
    figure,
    image(im); 
    truesize(gcf);
    c = 'r';
    s = '-';
    cwidth = 1.4;
    
    last = size(xs, 1);
    for i = 1:last
        x = xs(i, :);
        y = ys(i, :);
        line([x(1) x(2) x(3) x(4) x(1)]', [y(1) y(2) y(3) y(4) y(1)]', 'color', c, 'linewidth', cwidth, 'linestyle', s);
        hold on,
        line([x(5) x(6) x(7) x(8) x(5)]', [y(5) y(6) y(7) y(8) y(5)]', 'color', c, 'linewidth', cwidth, 'linestyle', s);
        hold on,
        line([x(1) x(5)]', [y(1) y(5)]', 'color', c, 'linewidth', cwidth, 'linestyle', s);
        hold on,
        line([x(4) x(8)]', [y(4) y(8)]', 'color', c, 'linewidth', cwidth, 'linestyle', s);
        hold on,
        line([x(2) x(6)]', [y(2) y(6)]', 'color', c, 'linewidth', cwidth, 'linestyle', s);
        hold on,
        line([x(3) x(7)]', [y(3) y(7)]', 'color', c, 'linewidth', cwidth, 'linestyle', s);
        if i < last
            hold on,
        end
    end
end