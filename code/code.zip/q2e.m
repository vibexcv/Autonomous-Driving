addpath(genpath(pwd));

testDir = fullfile('../data-car/test/left');
imgStorage = imageDatastore(testDir);
testFiles = imgStorage.Files;
numTestFiles = size(testFiles, 1);
carModel = getDataCar([], [], 'detector-car');

for i = 3:3
    % Load a image and its depth image
    fileName = testFiles(i);
    [filepath,imgName,ext] = fileparts(char(fileName));
    imdata = getDataCar(imgName, 'test', 'left');
    im = imdata.im;
    depthImg = getDataCar(imgName, 'test', 'depth');
    
    % Load detected cars (dss; not img) in the test image
    testData = getDataCar(imgName, 'test', 'ds');
    temp = testData.dss;
    temp = temp{1};
    dsCar = temp.carDS;
    
    % Get segmented points
    if ~isempty(dsCar)
        [width, length, rbg] = size(im);
        tempImg = zeros(width, length);
        result = simpleSegmentation(depthImg, dsCar, 150, tempImg);
        xs = [];
        ys = [];
        % draw boxes for each detected car
        for j = 1:size(result, 1)
            % filter out depth outliers
            segmentPts = result{j};
            isDepthOutlier = isoutlier(segmentPts(:,3));
            segmentPts = [segmentPts isDepthOutlier];
            segmentPts = segmentPts(find(isDepthOutlier == 0), :);
            z = segmentPts(:,3);
            
            zClosest = min(z);
            minRows = segmentPts(z == zClosest, :);
            xClosest = round(mean(minRows(:,1)));
            yClosest = round(mean(minRows(:,2)));
            
            zFurthest = max(z);
            maxRows = segmentPts(z == zFurthest, :);
            xFurthest = round(mean(maxRows(:,1)));
            yFurthest = round(mean(maxRows(:,2)));
            
            ds = dsCar(j,:);
            wCenter = ds(3) - ds(1);
            hCenter = ds(4) - ds(2);
            xCenter = round(ds(1) + wCenter/2);
            yCenter = round(ds(2) + hCenter/2);
            zCenter = depthImg(round(yCenter, xCenter));

            ratioClosest = zCenter / zClosest;
            closestW = wCenter * ratioClosest;
            closestH = hCenter * ratioClosest;
            
            ratioFurthest = zCenter / zFurthest;
            furthestW = wCenter * ratioFurthest;
            furthestH = hCenter * ratioFurthest;
            
            zClosest
            zCenter
            zFurthest
           
            x1 = xClosest - closestW/2;
            y1 = yClosest - closestH/2;
            x2 = x1 + closestW;
            y2 = y1;
            x3 = xClosest + closestW/2;
            y3 = yClosest + closestH/2;
            x4 = x1;
            y4 = y1 + closestH;
            
            x5 = xFurthest - furthestW/2;
            y5 = yFurthest - furthestH/2;
            x6 = x5 + furthestW;
            y6 = y5;
            x7 = xFurthest + furthestW/2;
            y7 = yFurthest + furthestH/2;
            x8 = x5;
            y8 = y5 + furthestH;
            
            xs = [xs; x1 x2 x3 x4 x5 x6 x7 x8];
            ys = [ys; y1 y2 y3 y4 y5 y6 y7 y8];
        end
        draw3Dbox(im, xs, ys);
    end
end