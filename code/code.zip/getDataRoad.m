function data = getDataRoad(imname, imset, whatdata)

% example to run: data = getData('000120', 'train', 'left');
% to load a detector, e.g.: data = getData([],[],'detector-car');

if nargin < 2
    fprintf('run with: data = getData(imname, imset, whatdata);\n');
    fprintf('where:\n');
    fprintf('   imset: ''train'' or ''test''\n');
    fprintf('   whatdata: ''list'', ''left'', ''right'', ''calib'', ''disp'', ''gt''\n')
    fprintf('   ''left-plot'' and ''right-plot'' and ''disp-plot'' will plot the data\n');
    fprintf('if the function doesn''t work, please check if globals.m is correctly set\n');
end;

globals;
data = [];

switch whatdata
    case {'list'}
        fid = fopen(fullfile(DATA_DIR_ROAD, imset, [imset '.txt']), 'r+');
        ids = textscan(fid, '%s');
        ids = ids{1};
        fclose(fid);
        data.ids = ids;
    case {'left', 'left-plot', 'right', 'right-plot'}
        imname = sprintf('um_%s',imname);
        leftright = strrep(whatdata, '-plot', '');
        imfile = fullfile(DATA_DIR_ROAD, imset, leftright, sprintf('%s.png', imname));
        im = imread(imfile);
        data.im = im;
        if strcmp(whatdata, sprintf('%s-plot', leftright))
            figure('position', [100,100,size(im,2)*0.7,size(im,1)*0.7]);
            subplot('position', [0,0,1,1]);
            imshow(im);
        end;
%     case {'disp'}   %disparity
%         imname = sprintf('%s',imname);
%         dispdir = fullfile(DATA_DIR_ROAD, imset, 'results');
%         dispfile = fullfile(dispdir, sprintf('%s_disparity.mat', imname));
%         if ~exist(dispfile, 'file')
%             fprintf('you haven''t computed disparity yet...\n');
%         end;
%         data.disparity = load(dispfile,'disparityMap');
case {'disp', 'disp-plot'}
        dispdir = fullfile(DATA_DIR_ROAD, imset, 'results');
        dispfile = fullfile(dispdir, sprintf('%s_left_disparity.png', imname)); 
        if ~exist(dispfile, 'file')
            fprintf('you haven''t computed disparity yet...\n');
        else
            disparity = imread(dispfile);
            disparity = double(disparity)/256;
        end;
        data.disparity = disparity;
        if strcmp(whatdata, 'disp-plot')
            figure('position', [100,100,size(disparity,2)*0.7,size(disparity,1)*0.7]);
            subplot('position', [0,0,1,1]);
            imagesc(disparity);
            axis equal;
        end;
        
    case {'calib'}
        % read internal params
        imname = sprintf('um_%s',imname);
        calib_dir = fullfile(DATA_DIR_ROAD, imset, 'calib');
        [~, ~, calib] = loadCalibration(fullfile(calib_dir, sprintf('%s.txt', imname)));
        [Kl,~,tl] = KRt_from_P(calib.P_rect{3});  % left camera
        [~,~,tr] = KRt_from_P(calib.P_rect{4});  % right camera
        f = Kl(1,1);
        baseline = abs(tr(1)-tl(1));   % distance between cams
        data.f = f;
        data.baseline = baseline;
        data.K = Kl;
        data.P_left = calib.P_rect{3};
        data.P_right = calib.P_rect{4};
    
    case {'gt'}
        % get the ground truth
        imname = sprintf('um_road_%s',imname);
        imdir = fullfile(DATA_DIR_ROAD, imset, 'gt_image_2','road');
        imfile = fullfile(imdir, sprintf('%s.png', imname));
        if ~exist(imfile, 'file')
            fprintf('you dont have the gt file...\n');
        end;
        im = imread(imfile);
        data.gt = im;
    
    case {'depth'}
        % get the depth
        imdir = fullfile(DATA_DIR_ROAD, imset, 'results');
        imfile = fullfile(imdir, sprintf('%s_depth.mat', imname));
        if ~exist(imfile, 'file')
            fprintf('you dont have the gt file...\n');
        end;
        data.depth = load(imfile,'depth');
    case {'model'}
        % get the model
        fileLocation = sprintf('%s/%s/model.mat', DATA_DIR_ROAD,imset);
        if ~exist(fileLocation, 'file')
            fprintf('you dont have the model file...\n');
        end;
        model = load(fileLocation,'svmmodel');
        data.svmmodel = model.svmmodel;
        
    case {'test-gt'}
        gtdir = fullfile(DATA_DIR_ROAD, imset, 'results');
        gtfile = fullfile(gtdir, sprintf('%s_gt_prediction.png', imname)); 
        if ~exist(gtfile, 'file')
            fprintf('you haven''t computed gt yet...\n');
        else
            gt = imread(gtfile);
            gt = double(gt)/256;
        end;
        data.testgt = gt;
        if strcmp(whatdata, 'disp-plot')
            figure('position', [100,100,size(gt,2)*0.7,size(gt,1)*0.7]);
            subplot('position', [0,0,1,1]);
            imagesc(gt);
            axis equal;
        end;
                
end;
