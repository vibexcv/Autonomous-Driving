function features = extractHOGFeaturesFromImageArray(imgArray, hogFeatureSize)
    numImages = length(imgArray);
    features = zeros(numImages, hogFeatureSize, 'single');

    for i = 1:numImages
        img = imgArray{i};
        img = rgb2gray(img);
        % Apply pre-processing steps
        img = imbinarize(img);
        features(i, :) = HOG(img);
    end
end