addpath(genpath(pwd));

% Crop cars from train images and save them
numViewPoints = 12;
radTolerance = deg2rad(5);
[trainData, trainLabels] = getCarDataAndLabelsByViewpoints(numViewPoints, radTolerance);

% Remove label '0' from the labels
totalDataSize = length(trainLabels);
numUniqueLabels = length(unique(trainLabels));

if numUniqueLabels > numViewPoints
    numUniqueLabels = numUniqueLabels - 1;
end

saveCroppedCarImgs(trainData, trainLabels, numUniqueLabels, 10000, 30);

%% Load train car images
[carTrainData, carLabels] = loadCroppedCarDataAndLabels('train');

%% Train car classifier for each viewpoint
hog4x4FeatureSize = 3*3*9;
uniqueLabels = unique(carLabels);
numUniqueLabels = length(uniqueLabels);
classifiers = cell(numUniqueLabels, 1);

% Train classifier for each viewpoint
trainingFeatures = extractHOGFeaturesFromImageArray(carTrainData, hog4x4FeatureSize);
    
for i = 1:numUniqueLabels
    defaultLabel = str2num(uniqueLabels{i});
    classifiers{i} = trainCarClassifierForViewpoint(carTrainData, carLabels, defaultLabel, trainingFeatures, numUniqueLabels);
end

%% Test sampling
testDir = fullfile('../data-car/test/left');
imgStorage = imageDatastore(testDir);
testFiles = imgStorage.Files;
numTestFiles = length(testFiles);
carModel = getDataCar([], [], 'detector-car');

% Detect then crop cars in each test image and save them for next (skip this if already done)
for i = 1:numTestFiles
    % Load a test image
    fileName = testFiles(i);
    [filepath,imgName,ext] = fileparts(char(fileName));
    imdata = getDataCar(imgName, 'test', 'left');
    im = imdata.im;
    imr = imresize(im, 1.5); % Resize img for efficiency (f = 1.5)
    
    % Detect cars (compute ds) in the test image
    for j = 1:length(classifiers)
        model = classifiers{i};
        carDS = detectObject(im, model.ModelParameters);
    end
    
    % Save car ds
    fileLocation = sprintf('../data-car/test/results/%s_car.mat', imgName);
    save(fileLocation, 'carDS');
end

% Load detected cars (dss; not img) in the test image
testData = getDataCar(imgName, 'test', 'ds');
temp = testData.dss;
temp = temp{1};
carDS = temp.carDS;

if ~isempty(carDS)
    % Crop each detected cars from the image and save them
    croppedCars = cropCarUsingDs(im, carDS);
    for j = 1:length(croppedCars)
        fileName = sprintf('../data-car/test/cropped-cars/car_%s_%d_%d.png', imgName, i, j);
        imwrite(croppedCarImg, fileName);
    end
    
    % Load cropped car images
    [carTestData, carTestLabels] = loadCroppedCarDataAndLabels('test');
    % Extract features of cars
    testFeatures = extractHOGFeaturesFromImageArray(carTestData, hog4x4FeatureSize);
end
    
% Classify the cropped cars against each viewpoint model
count = 0;
for k = 1:length(classifiers)
    label = predict(classifiers{k}, testFeatures);
    if length(unique(label)) > 1
        [label carTestLabels]
        count = count + 1;
    end
end

if count == 0
    fprintf('No detected cars were classified.\n');
end


