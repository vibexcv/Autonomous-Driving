function [trainData, labels] = getCarDataAndLabelsByViewpoints(numViewPoints, tolerance)
    trainingDir = fullfile('../data-car', 'train', 'left');
    dataObjectLabelDir = fullfile('../data-car', 'data-object-label', 'training', 'label');

    trainingSet = imageDatastore(trainingDir);

    trainingfiles = trainingSet.Files;
    numTrainingFiles = length(trainingfiles);

    trainData = {};
    labels = {};

    for i = 1:numTrainingFiles
        fileName = trainingfiles(i);
        [filepath,imgName,ext] = fileparts(char(fileName));
        imgData = getDataCar(imgName, 'train', 'left');
        img = imgData.im;

        objectLabelFile = fullfile(dataObjectLabelDir, sprintf('%s.txt', imgName));
        fileID = fopen(objectLabelFile);
        if fileID == -1
            fprintf('Could not open file: %s\n', sprintf('%s.txt', imgName));
            continue;
        else
            %     type          truncated occluded alpha bbox(left, top, right, bottom)   dimensions(h, w, l) location          rotation_y
            % ex. Pedestrian    0         0        -0.2  [(712,143),(810,308)]            (1.89,0.48,1.2)     (1.84,47,8.41.1)  -1.56
            tempC = textscan(fileID, '%s %f %f %f %f %f %f %f %f %f %f %f %f %f %f');
            fclose(fileID);
            tempLabels = tempC{1};
            % [x_left, y_top, x_right, y_bottom]
            [l, t, r, b] = tempC{5:8};
            radians = tempC{4};
            numObjects = length(tempLabels);
    %         figure;
    %         imshow(img);
            for j = 1:numObjects
                templabel = tempLabels{j};
                if strcmp(templabel,'Car') == 1
                    % Crop car from image
                    cropped = imcrop(img, [l(j) t(j) r(j)-l(j) b(j)-t(j)]);
    %                 figure;
    %                 imshow(cropped);
                    rad =  radians(j);
                    % Get label by radian group to which the car belongs(1~12)
                    label = getLabelByRadian(rad, tolerance, numViewPoints);
                    trainData = [trainData; cropped];
                    labels = [labels; label];
                end
            end
        end
    end
end

% Categorize negative train imgs into 12 view-points
% Angle (y-rotation) categories: [0,30), [30,60), .. [330,360)
function label = getLabelByRadian(rad, tolerance, numViewPoints)
    label = '0';

    %rad = rad + deg2rad(180);
    deg = rad2deg(rad);
    
    angleJump = 360 / numViewPoints;
    for i = 1:numViewPoints
        radAtVP = deg2rad(i*angleJump - 180);
        lowerBound = radAtVP - tolerance;
        upperBound = radAtVP + tolerance;
        
        if i == numViewPoints
            if lowerBound <= rad | -rad < -radAtVP + tolerance
                label = int2str(i);
                break;
            end
        else
            if lowerBound <= rad & rad < upperBound
                label = int2str(i);
                break;
                %fprintf('lowerbound:%f, upperbound:%f, rad:%f, label:%s\n\n',lowerBound, upperBound, rad, label);
            end
        end
    end
end