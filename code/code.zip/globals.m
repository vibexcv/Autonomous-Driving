SPSSTEREO_PATH = 'spsstereo';
DATA_DIR_CAR = '../data-car';
DATA_DIR_ROAD = '../data-road';
DETECTOR_DIR = fullfile(DATA_DIR_CAR, 'detectors');