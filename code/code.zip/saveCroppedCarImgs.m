function saveCroppedCarImgs(carTrainData, carLabels, numUniqueLabels, limit, minImgSize)
    idxSetForLabels = cell(numUniqueLabels, 1);
    for i = 1:numUniqueLabels
        idxSetForLabels{i} = find(contains(carLabels, int2str(i)));
        numIdx = size(idxSetForLabels{i}, 1);
        idxSet = idxSetForLabels{i};
        for j = 1:min(numIdx, limit)
            idx = idxSet(j);
            carImg = carTrainData{idx};
            [x, y] = size(carImg);
            if x < minImgSize | y < minImgSize
                continue
            else
                fileName = sprintf('../data-car/train/cropped-cars/car_%d_%d.png', i, j);
                imwrite(carImg, fileName);
            end
        end
        
%         limit = min(limit, size(idxSetForLabels{i}));
    end

    % Save cropped cars by number limit
%     for i = 1:numUniqueLabels
%         idxSet = idxSetForLabels{i};
%         for j = 1:limit
%             idx = idxSet(j);
%             carImg = carTrainData{idx};
%             fileName = sprintf('../data-car/train/cropped-cars/car_%d_%d.png', i, j);
%             imwrite(carImg, fileName);
%         end
%     end
end